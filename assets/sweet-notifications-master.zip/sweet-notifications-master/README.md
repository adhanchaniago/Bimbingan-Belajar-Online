# sweet-notifications
A simple and elegant Javascript library with no dependencies, to display sweet notifications!
